import java.util.Scanner;

class Test {

// +VISIBLE

public static void salutations( int nb_répétitions ) {
	for ( int i = 0; i < nb_répétitions; i++ ) {
		System.out.println( "Bonjour le monde!" );
	}
}

public static void main( String[] args ) {
	Scanner scan = new Scanner( System.in );

	int nb_entré = scan.nextInt();

// +TODO



// -TODO
}
// -VISIBLE
}
