# +VISIBLE
def salutations( nb_répétitions ):
    for i in range( nb_répétitions ):
        print( "Bonjour le monde!" )


nb_entré = int( input() )
# +TODO


# -TODO
# -VISIBLE
