#+VISIBLE
nb_répétitions = int( input() )

#+TODO

print( "Bonjour le monde" )

#-TODO

#-VISIBLE
