import java.util.Scanner;

public class exec {

//+VISIBLE

public static void main(String[] args) {

	Scanner input = new Scanner( System.in );
		
	nb_répétitions = input.nextInt();

//+TODO

	System.out.println( "Bonjour le monde" );

//-TODO

	}
	
//-VISIBLE

}
